****************
SNAKE GAME
****************

A classic snake game developed with python using the pygame library. The game consists of all features of a classic snake game.
_____________________________________________________________________________________________________________________________________

##################
HOW TO RUN
##################

1. Install pygame library:
Download the Python 3 installer package from the official website and install it, if not installed previously.

Run the following in the terminal to install the Pygame library

pip install pygame


2. Run the python file:
Get the source code and resources folder, put them in the same parent folder and run the .py file.

python3 Snake.py

________________________________________________________________________________________________________________________________________

######################
TEAM MEMBERS
######################

Rohit NS - 20BAI10030
Abin Chandran - 20BAI10089
Ram Govind V - 20BAI10143
Jessica Johny - 20BAI10193

